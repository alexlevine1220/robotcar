from setuptools import setup, find_packages


def readme():
    with open('README.md') as f:
        README = f.read()
    return README


setup(
    name="robotcar",
    version="1.0.0",
    description="robotcar simulator package for education",
    long_description=readme(),
    long_description_content_type="text/markdown",
    author="UCSD Robotic Lab",
    packages=[package for package in find_packages()
                if package.startswith('gym')],
    author_email="g5hwang@ucsd.edu",
    license="MIT",
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
    ],
    include_package_data=True,
    install_requires=[],
)
